
<html>

<head>

<meta charset="UTF-8" />

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="robots" content="follow" />

<meta name="viewport" content="width=device-width, initial-scale=1">

         <meta name="keywords" content="Hacked, Defaced, Stamped, Kissed, Secured, Terkentod!!" />

         <meta name="description" content="What's All This For? Of course all of this is for mere enjoyment hahaha." />

<meta name="theme-color" content="#000">

<meta name="viewport" content="width=750" />

<link rel="SHORTCUT ICON" href="https://upload.wikimedia.org/wikipedia/commons/a/a2/Jack-o%27-Lantern_2003-10-31.jpg">

<title>Hacked By ./Bullz</title>

<meta name="og:title" content="Hacked By Me | Bullz">

<link href="https://fonts.googleapis.com/css?family=Averia+Sans+Libre" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Wallpoet" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Architects+Daughter" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Sirin+Stencil" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Coming+Soon" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Metamorphous" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Rancho&effect=shadow-multiple" rel="stylesheet" type="text/css">

<link href='https://fonts.googleapis.com/css?family=New+Rocker' rel='stylesheet' type='text/css'>

<meta http-equiv="content-type" content="text/html;charset=utf-8">

</head>

<body bgcolor="black">

<center>

<br><br><br><br><br>

<center><img height="300px" id="images" src="https://i.top4top.io/p_1841fvcq80.jpg"></center> </b></b></div></div></body>

<script type="17cbfd1efa967f927b8d4b47-text/javascript"> //form tags to omit in NS6+: var omitformtags=["input", "textarea", "select"] omitformtags=omitformtags.join("|") function disableselect(e){ if (omitformtags.indexOf(e.target.tagName.toLowerCase())==-1)(typeof document.onselectstart!="undefined") document.onselectstart=new Function ("return false") else{ document.onmousedown=disableselect document.onmouseup=reEnable } </script>

<body onkeydown="if (!window.__cfRLUnblockHandlers) return false; return false" data-cf-modified-17cbfd1efa967f927b8d4b47-="">

<div style="color:white;font:9pt Courier New;"></div> <br>

<div style="color:white;font:15pt Courier New;"><font color="#FF0000"><b>Hacked By ./Bullz</font></div></b> <br>

<div style="color:white;font:15pt Arial;text-shadow:maroon 7px 2px 11px;"><font face="New Rocker"><b>Note:</b><a style="color:grey;font:15pt Courier New;"> <font color="white"> Nothing You Need To Know. <br>

<br>

<div style="color:white;font:12pt Courier New;"><font color="#FF0000"><b>Thank`s To : <br> ArdyanX - Cripto - Danielz - Meguminz - C3POT - Jiilan<br>Mughy - P34C3_KHYR3IN - DarkSec - Prof - Larry/Syahrul - Leri1337<br>K4ngHoax - R27 - #Ordinary_Human <br><br><br><font color="grey">contact : pecinta.loli1337@gmail.com

<iframe width="1" height="1" src="https://g.top4top.io/m_1855n8i241.mp3" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen=""></iframe>

<style>

a:link, a:visited {

    color: #fff;

    text-decoration: none;

}

button, input.button {

    padding: 4px 10px;

    cursor: pointer;

    font-family: Ubuntu;

    background: #c0392b;

    border: 0;

    border-radius: 3px;

    background: linear-gradient(#962a1f,#9c1c0f);

}

button, input.button {

    padding: 4px 10px;

    cursor: pointer;

    font-family: Tahoma,Verdana,Arial,sans-serif;

    background: #c0392b;

    border: 0;

    border-radius: 3px;

    background: linear-gradient(#962a1f,#9c1c0f);

}

global.min.css:2

button, input.button, select {

    font-size: 13px;

    color: #fff;

    outline: 0;

}



user agent stylesheet

input, textarea, select, button {

    text-rendering: auto;

    color: initial;

    letter-spacing: normal;

    word-spacing: normal;

    text-transform: none;

    text-indent: 0px;

    text-shadow: none;

    display: inline-block;

    text-align: start;

    margin: 0em;

    font: 400 13.3333px Arial;

}

user agent stylesheet

input, textarea, select, button, meter, progress {

    -webkit-writing-mode: horizontal-tb;



button, input.button, select {

    font-size: 13px;

    color: #fff;

    outline: 0;

}

    </style>

<div style="color:white;font:15pt Courier New;"><font color="#FF0000"></font></div>

</html>